# મારો પ્રવાસ હિસાબ — Android APK પ્રોજેક્ટ

આ પ્રોજેક્ટ તમારી `Pravas_Budget_App.html` ફાઇલને Android WebView માં પેક કરે છે. HTML ને `app/src/main/assets/index.html` તરીકે સામેલ કરવામાં આવી છે, એટલે એપની મુખ્ય સ્ક્રીન ઇન્ટરનેટ વિના ખુલી શકે છે.

## APK બનાવવા માટે

1. કમ્પ્યુટર પર Android Studio ઇન્સ્ટોલ કરો: https://developer.android.com/studio
2. ZIP ફાઇલ extract કરો.
3. Android Studio → Open → extract કરેલો `MaroPravasHisab_AndroidProject` ફોલ્ડર પસંદ કરો.
4. Gradle sync પૂર્ણ થવા દો. જરૂરી Android SDK/Gradle ઘટકો ડાઉનલોડ કરવા ઇન્ટરનેટ લાગી શકે.
5. મેનુમાં **Build → Build Bundle(s) / APK(s) → Build APK(s)** પસંદ કરો.
6. સફળ થયા પછી APK સામાન્ય રીતે અહીં મળશે:
   `app/build/outputs/apk/debug/app-debug.apk`
7. APK ફોનમાં મોકલો અને ઇન્સ્ટોલ કરો. ફોનમાં “Install unknown apps” જેવી પરવાનગી માંગે તો ફક્ત તમારી પોતાની બનાવેલી ફાઇલ માટે જ સાવચેતીપૂર્વક મંજૂરી આપો.

## Offline અને ડેટા વિશે

- HTML ફાઇલ એપમાં જ સામેલ છે, એટલે સ્ક્રીન ખોલવા ઇન્ટરનેટ જરૂરી નથી.
- જો HTML એપ ડેટા સાચવવા `localStorage` વાપરે છે, તો Android WebView માં DOM storage સક્રિય છે. તેમ છતાં, APK બનાવ્યા પછી ખર્ચ ઉમેરો/ફરી ખોલો/ફોન રીસ્ટાર્ટ પછી ડેટા રહે છે કે નહીં તેની ચકાસણી કરો.
- એપ uninstall કરવાથી એપમાં સાચવેલો સ્થાનિક ડેટા મટી શકે છે. મહત્વના ખર્ચનો બેકઅપ રાખો.
- આ પ્રોજેક્ટ તૈયાર સ્રોત-ફાઇલો છે; APK અહીં બનાવાયેલો/સાઇન થયેલો નથી. APK બનાવવા Android Studio જરૂરી છે.
- Play Store પર પ્રકાશિત કરવા અથવા બીજા લોકોને વિતરણ કરવા માટે release APK ને signing key વડે sign કરવું પડે. Keystore અને પાસવર્ડ સુરક્ષિત રાખો; અહીં અથવા ચેટમાં શેર ન કરો.
